
import { Component, ChangeDetectionStrategy, signal, OnInit, computed } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { StatBarComponent } from './components/stat-bar/stat-bar.component';
import { GlitchTextComponent } from './components/glitch-text/glitch-text.component';

interface CarCustomization {
  performance: {
    engine: number;
    aero: number;
    suspension: number;
    tires: number;
  };
  visuals: {
    camouflage: 'None' | 'Urban Digital' | 'Hex-Weave' | 'Active Phase';
    lighting: 'Stock Neon' | 'Pulse Wave' | 'Quantum Blue';
    projection: 'None' | 'Glitch Skull' | 'Data Stream';
  };
  paint: {
    primaryColor: string;
    material: 'Gloss' | 'Matte' | 'Chrome' | 'Carbon Fiber';
  };
}


interface Car {
  id: number;
  name: string;
  class: string;
  imageUrl: string;
  stats: { label: string; value: number }[];
  customization: CarCustomization;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, StatBarComponent, GlitchTextComponent, NgOptimizedImage],
})
export class AppComponent implements OnInit {
  isBooting = signal(true);
  bootProgress = signal(0);
  bootMessage = signal('INITIALIZING CORE SYSTEMS...');
  
  view = signal<'selection' | 'customization'>('selection');
  carToCustomize = signal<Car | null>(null);

  // Customization Options
  readonly camouflageOptions: CarCustomization['visuals']['camouflage'][] = ['None', 'Urban Digital', 'Hex-Weave', 'Active Phase'];
  readonly lightingOptions: CarCustomization['visuals']['lighting'][] = ['Stock Neon', 'Pulse Wave', 'Quantum Blue'];
  readonly projectionOptions: CarCustomization['visuals']['projection'][] = ['None', 'Glitch Skull', 'Data Stream'];
  readonly materialOptions: CarCustomization['paint']['material'][] = ['Gloss', 'Matte', 'Chrome', 'Carbon Fiber'];


  cars: Car[] = [
    {
      id: 1,
      name: 'Void Runner',
      class: 'Hyper-Class Interceptor',
      imageUrl: 'https://picsum.photos/seed/car1/1000/600',
      stats: [
        { label: 'Speed', value: 95 },
        { label: 'Acceleration', value: 88 },
        { label: 'Handling', value: 75 },
        { label: 'Armor', value: 40 },
        { label: 'E.M.P.', value: 65 },
      ],
      customization: {
        performance: { engine: 85, aero: 90, suspension: 70, tires: 80 },
        visuals: { camouflage: 'None', lighting: 'Quantum Blue', projection: 'None' },
        paint: { primaryColor: '#00e1ff', material: 'Gloss' }
      }
    },
    {
      id: 2,
      name: 'Juggernaut',
      class: 'Heavy Assault',
      imageUrl: 'https://picsum.photos/seed/car2/1000/600',
      stats: [
        { label: 'Speed', value: 60 },
        { label: 'Acceleration', value: 45 },
        { label: 'Handling', value: 55 },
        { label: 'Armor', value: 98 },
        { label: 'Payload', value: 85 },
      ],
      customization: {
        performance: { engine: 50, aero: 30, suspension: 80, tires: 90 },
        visuals: { camouflage: 'Urban Digital', lighting: 'Stock Neon', projection: 'None' },
        paint: { primaryColor: '#ff4b1f', material: 'Matte' }
      }
    },
    {
      id: 3,
      name: 'Wraith',
      class: 'Stealth Scout',
      imageUrl: 'https://picsum.photos/seed/car3/1000/600',
      stats: [
        { label: 'Speed', value: 85 },
        { label: 'Acceleration', value: 92 },
        { label: 'Handling', value: 95 },
        { label: 'Armor', value: 30 },
        { label: 'Cloaking', value: 90 },
      ],
      customization: {
        performance: { engine: 90, aero: 95, suspension: 85, tires: 75 },
        visuals: { camouflage: 'Active Phase', lighting: 'Pulse Wave', projection: 'Glitch Skull' },
        paint: { primaryColor: '#c3c3c3', material: 'Chrome' }
      }
    }
  ];

  gameModes = [
    { name: 'Circuit Race', description: 'High-speed track domination.' },
    { name: 'Deathmatch', description: 'Last vehicle standing wins.' },
    { name: 'Data Heist', description: 'Infiltrate, extract, and escape.' },
  ];

  selectedCarIndex = signal(0);
  selectedCar = computed(() => this.cars[this.selectedCarIndex()]);
  selectedGameMode = signal(this.gameModes[0].name);

  ngOnInit() {
    this.runBootSequence();
  }

  runBootSequence() {
    const messages = [
      'LOADING NEURAL INTERFACE...',
      'CALIBRATING THRUST VECTORS...',
      'SYNCING WITH SKYNET...',
      'SYSTEMS ONLINE. WELCOME, PILOT.'
    ];
    let messageIndex = 0;
  
    const interval = setInterval(() => {
      this.bootProgress.update(p => p + 1);
      if (this.bootProgress() % 25 === 0 && messageIndex < messages.length) {
          this.bootMessage.set(messages[messageIndex]);
          messageIndex++;
      }
      if (this.bootProgress() >= 100) {
        clearInterval(interval);
        setTimeout(() => {
            this.isBooting.set(false);
        }, 500);
      }
    }, 40);
  }

  selectNextCar() {
    this.selectedCarIndex.update(i => (i + 1) % this.cars.length);
  }

  selectPrevCar() {
    this.selectedCarIndex.update(i => (i - 1 + this.cars.length) % this.cars.length);
  }

  selectGameMode(modeName: string) {
    this.selectedGameMode.set(modeName);
  }

  getAnimationDelay(index: number): string {
    return `${0.5 + index * 0.1}s`;
  }
  
  // --- Customization Methods ---

  startCustomization() {
    // Deep copy the selected car to allow for discarding changes
    this.carToCustomize.set(JSON.parse(JSON.stringify(this.selectedCar())));
    this.view.set('customization');
  }

  saveAndExitCustomization() {
    const customizedCar = this.carToCustomize();
    if (!customizedCar) return;

    const index = this.cars.findIndex(c => c.id === customizedCar.id);
    if (index !== -1) {
      // Update the original car data with the new customizations
      this.cars[index] = customizedCar;
    }
    
    // Switch back to selection view
    this.view.set('selection');
    this.carToCustomize.set(null);
  }

  cancelCustomization() {
    this.view.set('selection');
    this.carToCustomize.set(null);
  }

  updatePerformance(stat: keyof CarCustomization['performance'], event: Event) {
    const value = parseInt((event.target as HTMLInputElement).value, 10);
    this.carToCustomize.update(car => {
      if (car) {
        car.customization.performance[stat] = value;
      }
      return car;
    });
  }
  
  updateVisual<T extends keyof CarCustomization['visuals']>(
    stat: T, 
    value: CarCustomization['visuals'][T]
  ) {
    this.carToCustomize.update(car => {
      if (car) {
        car.customization.visuals[stat] = value;
      }
      return car;
    });
  }

  updatePaint(prop: keyof CarCustomization['paint'], value: string) {
    this.carToCustomize.update(car => {
      if (car) {
        (car.customization.paint[prop] as string) = value;
      }
      return car;
    });
  }

  handleColorInput(event: Event) {
    const value = (event.target as HTMLInputElement).value;
    this.updatePaint('primaryColor', value);
  }
}
