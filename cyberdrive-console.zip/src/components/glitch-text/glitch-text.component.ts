
import { Component, ChangeDetectionStrategy, input } from '@angular/core';

@Component({
  selector: 'glitch-text',
  template: `
    <div class="glitch" [attr.data-text]="text()">{{ text() }}</div>
  `,
  styles: [`
    .glitch {
      position: relative;
      color: #00e1ff;
      text-shadow: 0 0 5px #00e1ff;
      animation: glitch-scan 3.5s linear infinite;
    }
    .glitch::before, .glitch::after {
      content: attr(data-text);
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: #01020d;
      overflow: hidden;
      clip: rect(0, 900px, 0, 0);
    }
    .glitch::before {
      left: 2px;
      text-shadow: -2px 0 #ff00c1;
      animation: glitch-anim-1 2s infinite linear alternate-reverse;
    }
    .glitch::after {
      left: -2px;
      text-shadow: -2px 0 #00fff9, 2px 2px #ff00c1;
      animation: glitch-anim-2 1s infinite linear alternate-reverse;
    }

    @keyframes glitch-anim-1 {
      0% { clip: rect(42px, 9999px, 44px, 0); }
      5% { clip: rect(17px, 9999px, 91px, 0); }
      10% { clip: rect(40px, 9999px, 17px, 0); }
      15% { clip: rect(81px, 9999px, 63px, 0); }
      20% { clip: rect(2px, 9999px, 83px, 0); }
      25% { clip: rect(69px, 9999px, 2px, 0); }
      30% { clip: rect(32px, 9999px, 94px, 0); }
      35% { clip: rect(5px, 9999px, 23px, 0); }
      40% { clip: rect(31px, 9999px, 80px, 0); }
      45% { clip: rect(72px, 9999px, 35px, 0); }
      50% { clip: rect(10px, 9999px, 98px, 0); }
      55% { clip: rect(74px, 9999px, 5px, 0); }
      60% { clip: rect(21px, 9999px, 66px, 0); }
      65% { clip: rect(88px, 9999px, 45px, 0); }
      70% { clip: rect(41px, 9999px, 91px, 0); }
      75% { clip: rect(29px, 9999px, 5px, 0); }
      80% { clip: rect(59px, 9999px, 78px, 0); }
      85% { clip: rect(7px, 9999px, 34px, 0); }
      90% { clip: rect(47px, 9999px, 8px, 0); }
      95% { clip: rect(13px, 9999px, 57px, 0); }
      100% { clip: rect(61px, 9999px, 3px, 0); }
    }
    @keyframes glitch-anim-2 {
      0% { clip: rect(25px, 9999px, 48px, 0); }
      /* ... shortened for brevity ... */
      100% { clip: rect(8px, 9999px, 92px, 0); }
    }
    @keyframes glitch-scan {
      0%, 100% { height: 100%; }
      50% { height: 100%; }
      50.1% { height: 2px; }
      50.2% { height: 100%; }
      75.1% { height: 3px; }
      75.2% { height: 100%; }
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GlitchTextComponent {
  text = input.required<string>();
}
