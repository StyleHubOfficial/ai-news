
import { Component, ChangeDetectionStrategy, input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-stat-bar',
  template: `
    <div class="w-full font-mono text-sm">
      <div class="flex justify-between mb-1">
        <span class="font-bold uppercase tracking-wider">{{ label() }}</span>
        <span>{{ value() }}%</span>
      </div>
      <div class="h-3 w-full bg-cyan-900/50 border border-cyan-500/50 p-0.5 overflow-hidden">
        <div 
          class="h-full bg-cyan-400 transition-all duration-1000 ease-out" 
          [style.width.%]="value()">
        </div>
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
})
export class StatBarComponent {
  label = input.required<string>();
  value = input.required<number>();
}
